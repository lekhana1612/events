<!DOCTYPE html>
{%load static%}
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=<device-width>, initial-scale=1.0">
    <title>Document</title>
    <style media="screen">
        form *{
    font-family: 'Poppins',sans-serif;
   
    letter-spacing: 0.5px;
    outline: none;
    border: none;
  
    
        }
        button{
    margin-top: 10px;
    width: 20%;
    background-color:rgb(174, 138, 166);
    color: #080710;
    padding: 15px 0;
    font-size: 18px;
    font-weight: 600;
    border-radius: 5px;
    cursor: pointer;
}   
input{
    display: block;
    height: 50px;
    width: 20%;
    background-color: aliceblue;
    border-radius: 3px;
    padding: 0 10px;
    margin-top: 8px;
    font-size: 14px;
    font-weight: 300;
} 
select{
    display: block;
    height: 50px;
    width: 20%;
  
    border-radius: 3px;
    padding: 0 10px;
    margin-top: 8px;
    font-size: 14px;
    font-weight: 300;
} 

label{
    display: block;
    background-color: rgb(174, 187, 198);
    width:200px;
    font-size: 16px;
    font-weight: 800;
    color:rgb(56, 13, 56)
}
   h1{
    font-size:40px;
    color:rgb(59, 31, 31);
    background-color: rgb(174, 187, 198);
    width:450px;
   } 
   #bg{
    background-repeat: no-repeat;

    background-size: cover;
    background-attachment: fixed;
}

    </style>
    <script>
function calculate() {
    var myBox1 = parseFloat(document.getElementById('quotation').value);
    var myBox2 =  parseFloat(document.getElementById('advance').value);
    var result = document.getElementById('balance');
    var numb = myBox1 - myBox2;
    numb = numb.toFixed(8);
    result.value = numb;
  }

 function notif(){
    
    alert("submitted successfully!!")
    alert("you'll recieve a confirmation email from us at earliest")
    window.location="{% url 'logout' %}"
 }

  </script>
</head>
<body id="bg"style="background-image:url('{%static 'img/eventvenue.jpg'%}');">
    {{n}}
    <h1>Book your events here!!</h1>
    <form method="post" action= "{% url 'saveenquiry' %}" id="contact" role="form" novalidate="novalidate" class="bv-form">
        {% csrf_token %}
    <br>
    <br>
    <div class="row">
    <label>Customer Name:   </label><br>
         <input type="text" name="customername" class="box" id="customername" required autofocus>
    <br>
    <br>
    
    <label>Event Date:</label><br>
    <input type="date" name="eventdate" class="box" id="eventdate" required autofocus>
    <br>
    <br>
    <label for="eventname">Event :</label><br>
    <select name="eventname" id="eventname" class="box" required autofocus>
        <option value="select">----select----</option>
        <option value="wedding">Wedding</option>
        <option value="birthday">Birthday Party</option>
        <option value="anniversary">Wedding Anniversary</option>
        <option value="parties">Parties</option>
        <option value="babyshower">Baby Shower</option>
        <option value="naming">Naming Ceremony</option>
    </select>
    <br>
    <br>
    <label>Event Venue:</label><br>
    <textarea name="eventvenue" id="eventvenue" cols="30" rows="5"
                placeholder="your address"></textarea>
    <br>
    <br>
    <label for="eventname">Event City</label><br>
    <select name="eventcity" id="eventcity" class="box" required autofocus>
        <option value="select">----select----</option>
        <option value="beng">Bengaluru</option>
        <option value="mang">Mangaluru</option>
        <option value="udu">Udupi</option>
        <option value="kal">Kalburgi</option>
        <option value="chick">Chickkamagaluru</option>
        <option value="tum">Tumakuru</option>
        <option value="shiv">Shivamogga</option>
        <option value="dav">Davangere</option>
        <option value="kol">Kolar</option>
        <option value="has">Hassan</option>
        <option value="chik">Chikkaballapura</option>
        <option value="mys">Mysuru</option>
        <option value="mad">Madikeri</option>
        <option value="kan">Kanakpura</option>
        <option value="ram">Ramanagara</option>
        <option value="chan">Channapatna</option>
        <option value="mag">Magadi</option>
        <option value="dar">Dharwad</option>
        <option value="hub">Hubali</option>
        <option value="kar">Karwar</option>
        <option value="gun">Gundlupete</option>
        <option value="cham">Chanarajanagar</option>
        <option value="kop">Koppal</option>
        <option value="hav">Haveri</option>
        <option value="yad">Yadgir</option>
        </select>
        <br>
        <br>
    <label>Quotation:</label><br>
    <input type="text" name="quotation" placeholder="Rs." class="box" id="quotation" oninput="calculate()" required autofocus>
    <br>
    <br>
    <label>Advance:</label><br>
    <input type="text" name="advance" placeholder="Rs." class="box" id="advance" oninput="calculate()" required autofocus>
    <br>
    <br>
    <label>Remaining Amount:</label><br>
    <input type="text" name="balance" placeholder="Rs." class="box" id="balance" readonly>
    <br>
    <br>
    <br>
   <button type="submit" value="list" onclick="notif()">SUBMIT</button>
    <button type="reset">RESET</button>


   </div>
   </form> 

</body>
</html>