from django.contrib import admin
from customerdata.models import customerdata

# Register your models here.
class contactAdmin(admin.ModelAdmin):
    list_display=('customername','phone','email','eventdate','eventname','eventvenue','eventcity','quotation','advance','balance')

admin.site.register(customerdata,contactAdmin)
# Register your models here.
