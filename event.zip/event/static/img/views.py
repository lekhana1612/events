from django import forms
from django.shortcuts import render,HttpResponse,redirect
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse, HttpResponseNotFound
from userdata.models import userdata
from contactus.models import contactus


# Create your views here.
@login_required(login_url='login')
def HomePage(request):
    return render (request,'home.html')

def saveEnquiry(request):
    if request.method=="POST":
        customername=request.POST.get('customername')
        eventdate=request.POST.get('eventdate')
        eventname=request.POST.get('eventname')
        eventvenue=request.POST.get('eventvenue')
        eventcity=request.POST.get('eventcity')
        quotation=request.POST.get('quotation')
        advance=request.POST.get('advance')
        balance=request.POST.get('balance')
        en=userdata(customername=customername,eventdate=eventdate,eventname=eventname,eventvenue=eventvenue,eventcity=eventcity,quotation=quotation,advance=advance,balance=balance)
        en.save()
        n='data inserted'
    return render (request,"home.html",{'n':n})

def SignupPage(request):
    if request.method=='POST':
        uname=request.POST.get('username')
        email=request.POST.get('email')
        pass1=request.POST.get('password1')
        pass2=request.POST.get('password2')


        if pass1!=pass2:
            return HttpResponse("Your password and confirm password are not Same!!")
        else:

            my_user=User.objects.create_user(uname,email,pass1)
            my_user.save()
            return redirect('login')
        



    return render (request,'signup.html')

def LoginPage(request):
    if request.method=='POST':
        username=request.POST.get('username')
        pass1=request.POST.get('pass')
        user=authenticate(request,username=username,password=pass1)
        if user is not None:
            login(request,user)
            return redirect('home')
        else:
            return HttpResponse ("Username or Password is incorrect!!!")

    return render (request,'login.html')

def contactus(request):
    
    return render (request,'contactus.html')

def savemessage(request):
    if request.method=="POST":
        name=request.POST.get('name')
        email=request.POST.get('email')
        phone=request.POST.get('phone')
        message=request.POST.get('message')
        da=contactus(name=name,email=email,phone=phone,message=message)
        da.save()
        d='data inserted'
    return render (request,"contactus.html",{'d':d})

      
      




    
