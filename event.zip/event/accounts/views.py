from django import forms
from django.shortcuts import render,HttpResponse,redirect
from django.template.loader import render_to_string
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse, HttpResponseNotFound
from customerdata.models import customerdata
from feedback.models import feedback
from remainingAmt.models import remainingAmt
from django.core.mail import EmailMessage
from django.conf import settings
 

# Create your views here.
@login_required(login_url='login')
def HomePage(request):
    return render (request,'home.html')

#this is for book for new event page
def saveEnquiry(request):
    if request.method=="POST":
        
        customername=request.POST.get('customername')
        phone=request.POST.get('phone')
        email=request.POST.get('email')
        eventdate=request.POST.get('eventdate')
        eventname=request.POST.get('eventname')
        eventvenue=request.POST.get('eventvenue')
        eventcity=request.POST.get('eventcity')
        quotation=request.POST.get('quotation')
        advance=request.POST.get('advance')
        balance=request.POST.get('balance')
        en=customerdata(customername=customername,phone=phone,email=email,eventdate=eventdate,eventname=eventname,eventvenue=eventvenue,eventcity=eventcity,quotation=quotation,advance=advance,balance=balance)
        mydict={'customername':customername,'phone':phone,'email':email,'eventdate':eventdate,'eventname':eventname,'eventvenue':eventvenue,'eventcity':eventcity,'quotation':quotation,'advance':advance,'balance':balance}
        
        en.save()
        n='data inserted'
      
        

        #send_mail('The contact form subject','This is the message',['prevents02@gmail.com'],html_message=html)
        html_template='register_email.html'
        html_message= render_to_string(html_template,context=mydict,)
        subject='Welcome To PR Events'
        email_from=settings.EMAIL_HOST_USER
        recipient_list=[email]
        
        message=EmailMessage(subject,html_message,email_from,recipient_list)
        message.content_subtype='html'
        message.send()
      
    return render (request,"logout.html",{'n':n})


def SignupPage(request):
    if request.method=='POST':
        uname=request.POST.get('username')
        email=request.POST.get('email')
        pass1=request.POST.get('password1')
        pass2=request.POST.get('password2')


        if pass1!=pass2:
            return HttpResponse("Your password and confirm password are not Same!!")
        else:

            my_user=User.objects.create_user(uname,email,pass1)
            my_user.save()
            return redirect('login')
        



    return render (request,'signup.html')

def LoginPage(request):
    if request.method=='POST':
        username=request.POST.get('username')
        pass1=request.POST.get('pass')
        user=authenticate(request,username=username,password=pass1)
        if user is not None:
            login(request,user)
            return redirect('client')
        else:
            return HttpResponse ("Username or Password is incorrect!!!")

    return render (request,'login.html')

def feedback(request):
    
    return render (request,'feedback.html')



def gallery(request):
    return render (request,'gallery.html')
def about(request):
    return render (request,'about.html')
def logout(request):
    return render (request,'logout.html')
def register_email(request):
    return render (request,'register_email.html')
def register_email2(request):
    return render (request,'register_email2.html')
def ClientPage(request):
    return render (request,'client.html')
def amtpending(request):
    return render (request,'amtpending.html')

#this is for remaining amount page
def savedata(request):
    if request.method=="POST":
        customername=request.POST.get('customername')
        email=request.POST.get('email')
        quotation=request.POST.get('quotation')
        advance=request.POST.get('advance')
        balance=request.POST.get('balance')
        en=remainingAmt(customername=customername,email=email,quotation=quotation,advance=advance,balance=balance)
        mydict={'customername':customername,'email':email,'quotation':quotation,'advance':advance,'balance':balance}
        en.save()
        r='data inserted'
        html_template='register_email2.html'
        html_message= render_to_string(html_template,context=mydict)
        
       

    return render (request,"logout2.html",{'r':r})


 #this is for feedback  
def savemessage(request):
    if request.method=="POST":
        custname=request.POST.get('custname')
        
        email=request.POST.get('email')
        phone=request.POST.get('phone')
        message=request.POST.get('message')
        pn=feedback(custname=custname,email=email,phone=phone,message=message)
    
        pn.save()
        p='data inserted'
       
    return render (request,"feedback.html",{'p':p})
   
      




    
