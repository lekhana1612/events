from django.contrib import admin
from django.urls import include, path
from accounts import views
urlpatterns = [
    path('admin/', admin.site.urls),
    path('',views.SignupPage,name='signup'),
    path('login/',views.LoginPage,name='login'),
    path('home/',views.HomePage,name='home'),
    path('feedback/',views.feedback,name='feedback'),
    path('savemessage/',views.savemessage,name='savemessage'),
    path('gallery/',views.gallery,name='gallery'),
    path('about/',views.about,name='about'),
    path('logout/',views.logout,name='logout'),
    path('client/',views.ClientPage,name='client'),
    path('amtpending/',views.amtpending,name='amtpending'),
    path('savedata/',views.savedata,name='savedata'),
    path('register_email/',views.register_email,name='register_email'),

]
