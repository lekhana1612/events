from django.contrib import admin
from remainingAmt.models import remainingAmt

# Register your models here.
class contactAd(admin.ModelAdmin):
    list_display=('customername','email','quotation','advance','balance')

admin.site.register(remainingAmt,contactAd)