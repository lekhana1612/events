from django.apps import AppConfig


class RemainingamtConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'remainingAmt'
