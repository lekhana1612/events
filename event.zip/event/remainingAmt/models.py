from django.db import models

# Create your models here.
class remainingAmt(models.Model):
    customername=models.CharField(max_length=50)
    email=models.CharField(max_length=50)
    quotation=models.CharField(max_length=50)
    advance=models.CharField(max_length=50)
    balance=models.CharField(max_length=50)
